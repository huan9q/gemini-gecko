# Gemini Gecko — real Gemini in GeckoView

This is a native Android shell that displays the real `https://gemini.google.com/` website using Mozilla GeckoView.

It does not implement a fake Gemini UI and does not use Android WebView, Chrome Custom Tabs, or a PWA.

## Easiest build route: GitHub Actions

1. Create a new GitHub repository.
2. Upload the contents of this project, with `android/` at the repository root.
3. Open **Actions** → **Build Gemini Gecko APK**.
4. Run the workflow manually, or push to `main`.
5. When it finishes, open the workflow run and download the **gemini-gecko-release** artifact.
6. Inside that artifact is `app-release.apk`.

The workflow installs JDK 17, Android SDK 35/build-tools 35.0.0, Gradle 8.7, and builds the release APK in the cloud. A Gradle wrapper JAR is intentionally not required for this cloud workflow.

## Local Android Studio route

Open the `android/` directory as an existing Gradle project in Android Studio. Use a local Gradle 8.7 installation if Android Studio asks for a Gradle distribution. Then build the `release` variant.

## Engine

GeckoView is configured from Mozilla's Maven repository. The version in this project is `158.0.20260922210132`.
