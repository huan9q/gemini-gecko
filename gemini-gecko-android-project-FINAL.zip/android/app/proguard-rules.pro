# GeckoView ProGuard Rules
-keep class org.mozilla.geckoview.** { *; }
-keep interface org.mozilla.geckoview.** { *; }
-dontwarn org.mozilla.geckoview.**

# Keep Gecko JNI methods
-keepclasseswithmembernames class * {
    native <methods>;
}

# Keep JNI entry points for Gecko runtime
-keep class org.mozilla.gecko.** { *; }
-dontwarn org.mozilla.gecko.**

