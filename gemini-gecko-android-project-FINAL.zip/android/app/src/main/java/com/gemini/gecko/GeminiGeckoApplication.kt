package com.gemini.gecko

import android.app.Application
import android.util.Log
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings

/** Owns the single persistent Gecko engine for the process. */
class GeminiGeckoApplication : Application() {

    lateinit var geckoRuntime: GeckoRuntime
        private set

    override fun onCreate() {
        super.onCreate()
        geckoRuntime = GeckoRuntime.create(
            this,
            GeckoRuntimeSettings.Builder()
                .javaScriptEnabled(true)
                .webManifest(true)
                .aboutConfigEnabled(false)
                .consoleOutput(BuildConfig.DEBUG)
                .build()
        )
        Log.i(TAG, "GeckoRuntime initialized")
    }

    companion object {
        private const val TAG = "GeminiGeckoApp"
    }
}
