package com.gemini.gecko.gecko

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.annotation.MainThread
import org.mozilla.geckoview.AllowOrDeny
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings

/** Owns the persistent real Gemini GeckoSession. */
object GeckoSessionManager {

    private const val TAG = "GeckoSessionManager"
    const val GEMINI_URL = "https://gemini.google.com/"

    private val GOOGLE_DOMAINS = setOf(
        "gemini.google.com",
        "accounts.google.com",
        "myaccount.google.com",
        "oauth2.googleapis.com",
        "apis.google.com",
        "gstatic.com",
        "googleusercontent.com",
        "ssl.gstatic.com",
        "www.gstatic.com",
        "one.google.com",
        "support.google.com"
    )

    private var activeSession: GeckoSession? = null
    private var canGoBack = false

    @MainThread
    fun getOrCreateSession(context: Context, runtime: GeckoRuntime): GeckoSession {
        activeSession?.let { existing ->
            if (existing.isOpen) return existing
        }

        val session = GeckoSession(
            GeckoSessionSettings.Builder()
                // Persistent profile: retain Google authentication and web storage.
                .usePrivateMode(false)
                .viewportMode(GeckoSessionSettings.VIEWPORT_MODE_MOBILE)
                .userAgentMode(GeckoSessionSettings.USER_AGENT_MODE_MOBILE)
                .fullScreen(false)
                .build()
        )

        session.promptDelegate = GeckoPromptHandler(context.applicationContext)

        session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                GeckoSessionManager.canGoBack = canGoBack
            }

            override fun onLoadRequest(
                session: GeckoSession,
                request: GeckoSession.NavigationDelegate.LoadRequest
            ): GeckoResult<AllowOrDeny>? {
                val uri = Uri.parse(request.uri)
                val host = uri.host?.lowercase() ?: ""
                val allowed = GOOGLE_DOMAINS.any { domain ->
                    host == domain || host.endsWith(".$domain")
                }

                if (allowed) return GeckoResult.fromValue(AllowOrDeny.ALLOW)

                // Keep the dedicated Gemini shell focused on Gemini/Google auth.
                // External links are opened by Android's normal browser instead.
                return try {
                    context.startActivity(
                        Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                    GeckoResult.fromValue(AllowOrDeny.DENY)
                } catch (e: Exception) {
                    Log.w(TAG, "Unable to open external URL: $uri", e)
                    GeckoResult.fromValue(AllowOrDeny.DENY)
                }
            }
        }

        session.open(runtime)
        session.loadUri(GEMINI_URL)
        activeSession = session
        return session
    }

    fun goBack(): Boolean {
        val session = activeSession ?: return false
        return if (canGoBack) {
            session.goBack()
            true
        } else {
            false
        }
    }
}
