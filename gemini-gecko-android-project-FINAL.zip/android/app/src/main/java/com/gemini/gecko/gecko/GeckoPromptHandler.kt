package com.gemini.gecko.gecko

import android.content.Context
import android.net.Uri
import android.util.Log
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoSession

/**
 * GeckoPromptHandler manages web prompts for Gemini:
 * - File and image uploads (<input type="file">)
 * - Confirmation dialogues
 * - Media permissions
 */
class GeckoPromptHandler(
    private val context: Context
) : GeckoSession.PromptDelegate {

    private var filePromptCallback: ((Array<Uri>?) -> Unit)? = null

    fun setFilePickerCallback(callback: (Array<Uri>?) -> Unit) {
        this.filePromptCallback = callback
    }

    override fun onFilePrompt(
        session: GeckoSession,
        prompt: GeckoSession.PromptDelegate.FilePrompt
    ): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
        Log.d(TAG, "onFilePrompt: type=${prompt.type}, mimeTypes=${prompt.mimeTypes?.joinToString()}")

        val result = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()

        filePromptCallback?.let { callback ->
            callback { uris ->
                if (uris != null && uris.isNotEmpty()) {
                    if (prompt.type == GeckoSession.PromptDelegate.FilePrompt.Type.MULTIPLE) {
                        result.complete(prompt.confirm(context, uris))
                    } else {
                        result.complete(prompt.confirm(context, uris[0]))
                    }
                } else {
                    result.complete(prompt.dismiss())
                }
            }
        } ?: run {
            // Dismiss if no handler registered
            result.complete(prompt.dismiss())
        }

        return result
    }

    companion object {
        private const val TAG = "GeckoPromptHandler"
    }
}
