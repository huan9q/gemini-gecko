This project is prepared for a clean cloud build.
The included GitHub Actions workflow installs Gradle 8.7 directly, so the Gradle wrapper JAR is not needed.
The APK has NOT been claimed as built in this archive.
